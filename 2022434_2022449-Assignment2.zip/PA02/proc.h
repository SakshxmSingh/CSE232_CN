#if !defined(_PROC_H)
#define _PROC_H

typedef struct proc_info {
    char name[1000];
    char pid[1000];
    int user_time;
    int kernel_time;
} proc_info;

proc_info *get_proc_info();

#endif // _PROC_H
