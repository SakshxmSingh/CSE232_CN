#include "client.h"
#include "proc.h"
#include <arpa/inet.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Function to initialize connection with server
void *init_connection(void *arg) {
    // Extracting thread data from argument
    thread_data *data = (thread_data *)arg;
    socklen_t addr_len = sizeof(data->server_addr);

    // Convert address from text to binary form
    if (inet_pton(AF_INET, inet_ntoa(data->server_addr.sin_addr),
                  &data->server_addr.sin_addr) <= 0) {
        printf("Thread %d: Invalid address/Address not supported\n",
               data->thread_id);
        pthread_exit(NULL);
    }

    // Create socket
    int socket_fd;
    if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("Thread %d: Socket creation error\n", data->thread_id);
        pthread_exit(NULL);
    }

    // Connect to server
    if (connect(socket_fd, (const struct sockaddr *)&data->server_addr,
                addr_len) < 0) {
        printf("Thread %d: Connection Failed\n", data->thread_id);
        pthread_exit(NULL);
    }

    // Initialize message to send
    char hello[25] = "Hello from client-";
    char *thread_id_str = malloc(10);
    sprintf(thread_id_str, "%d", data->thread_id);
    strcat(hello, thread_id_str);
    const char *hello_msg = hello;

    // Send message to server
    send(socket_fd, hello_msg, strlen(hello_msg), 0);
    printf("Thread %d: Message sent to server\n", data->thread_id);

    // Receive message from server
    proc_info processes[2];
    read(socket_fd, processes, sizeof(processes));
    printf("---------Thread-%d---------\n", data->thread_id);
    printf("Process 1: %s\n", processes[0].name);
    printf("PID: %s\n", processes[0].pid);
    printf("User Time: %ds\n", processes[0].user_time);
    printf("Kernel Time: %ds\n", processes[0].kernel_time);
    printf("CPU Time: %ds\n",
           processes[0].user_time + processes[0].kernel_time);
    printf("\n");
    printf("Process 2: %s\n", processes[1].name);
    printf("PID: %s\n", processes[1].pid);
    printf("User Time: %ds\n", processes[1].user_time);
    printf("Kernel Time: %ds\n", processes[1].kernel_time);
    printf("CPU Time: %ds\n",
           processes[1].user_time + processes[1].kernel_time);
    printf("--------------------------\n");
    printf("\n");
    fflush(stdout);

    // Close connection
    free(thread_id_str);
    close(socket_fd);
    pthread_exit(NULL);
}

// Main function
int main(int argc, char const *argv[]) {
    // Check for correct number of arguments
    if (argc != 4) {
        printf("Usage: %s <server_ip> <server_port> <n_threads>\n", argv[0]);
        exit(1);
    }

    // Extracting arguments
    const char *server_ip = argv[1];
    int server_port = atoi(argv[2]);
    int n_threads = atoi(argv[3]);

    // Initialize server address
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    // Create threads
    pthread_t threads[n_threads];
    struct thread_data thread_data[n_threads];
    for (int i = 0; i < n_threads; i++) {
        thread_data[i].thread_id = i;
        thread_data[i].server_addr = server_addr;

        if (pthread_create(&threads[i], NULL, init_connection,
                           &thread_data[i]) != 0) {
            printf("Error creating thread %d\n", i);
        }
    }

    // Wait for all threads to finish
    for (int i = 0; i < n_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}
