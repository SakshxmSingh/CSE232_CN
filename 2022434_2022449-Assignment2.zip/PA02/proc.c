#include "proc.h"
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

proc_info *get_proc_info() {
    int max1, max2;
    int user_max1, kernel_max1, user_max2, kernel_max2;
    char proc1_name[1000], proc2_name[1000];
    char proc1_pid[1000], proc2_pid[1000];
    DIR *folder;
    struct dirent *entry;
    proc_info *processes = (proc_info *)malloc(2 * sizeof(proc_info));

    folder = opendir("/proc");
    if (folder == NULL) {
        perror("Unable to read directory");
        return NULL;
    }

    while ((entry = readdir(folder))) {
        if (entry->d_name[0] >= '0' && entry->d_name[0] <= '9') {
            char dirname[100] = "/proc/";
            strcat(dirname, entry->d_name);
            strcat(dirname, "/stat");
            int fd = open(dirname, O_RDONLY);
            if (fd == -1) {
                perror("Unable to open file");
                continue;
            }

            char buffer[1024];
            int n = read(fd, buffer, 1024);
            if (n == -1) {
                perror("Unable to read file");
                continue;
            }

            char *save_ptr;
            int counter = 0;
            int user_time, kernel_time;
            char curr_name[1000];
            char curr_pid[1000];

            char *token = strtok_r(buffer, " ", &save_ptr);
            while (token != NULL) {
                counter++;
                if (counter == 1) {
                    strlcpy(curr_pid, token, 1000);
                }
                if (counter == 2) {
                    strlcpy(curr_name, token, 1000);
                }
                if (counter == 14) {
                    user_time = atoi(token);
                }
                if (counter == 15) {
                    kernel_time = atoi(token);
                }
                token = strtok_r(NULL, " ", &save_ptr);
            }
            int total_time = user_time + kernel_time;

            if (total_time > max1 && strncmp(curr_pid, proc1_pid, 1000) != 0) {
                max2 = max1;
                max1 = total_time;
                user_max2 = user_max1;
                user_max1 = user_time;
                kernel_max2 = kernel_max1;
                kernel_max1 = kernel_time;
                strlcpy(proc2_name, proc1_name, 1000);
                strlcpy(proc2_pid, proc1_pid, 1000);
                strlcpy(proc1_name, curr_name, 1000);
                strlcpy(proc1_pid, curr_pid, 1000);
            } else if (total_time > max2 &&
                       strncmp(curr_pid, proc1_pid, 1000) != 0) {
                max2 = total_time;
                user_max2 = user_time;
                kernel_max2 = kernel_time;
                strlcpy(proc2_name, curr_name, 1000);
                strlcpy(proc2_pid, curr_pid, 1000);
            }
            close(fd);
        }
    }

    closedir(folder);

    strlcpy(processes[0].name, proc1_name, 1000);
    strlcpy(processes[0].pid, proc1_pid, 1000);
    processes[0].user_time = user_max1 / sysconf(_SC_CLK_TCK);
    processes[0].kernel_time = kernel_max1 / sysconf(_SC_CLK_TCK);

    strlcpy(processes[1].name, proc2_name, 1000);
    strlcpy(processes[1].pid, proc2_pid, 1000);
    processes[1].user_time = user_max2 / sysconf(_SC_CLK_TCK);
    processes[1].kernel_time = kernel_max2 / sysconf(_SC_CLK_TCK);

    return processes;
}
