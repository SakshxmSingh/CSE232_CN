#include "proc.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_CLIENTS 512
#define MAX_PROCESSES 2

int main(int argc, char const *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <port>\n", argv[0]);
        exit(1);
    }

    char buffer[1024];

    int server_fd, new_socket, client_socket[MAX_CLIENTS] = {0}, sd, max_sd;
    fd_set readfds;

    int port = atoi(argv[1]);
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket failed");
        exit(1);
    }

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) <
        0) {
        perror("Setsockopt failed");
        exit(1);
    }

    if (bind(server_fd, (struct sockaddr *)&address, addrlen) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(1);
    }

    if (listen(server_fd, 512) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(1);
    }

    printf("TCP select server listening on Port: %d\n",
           ntohs(address.sin_port));

    while (1) {
        FD_ZERO(&readfds);           // clear the FD set
        FD_SET(server_fd, &readfds); // add the server fd to the fdset
        max_sd = server_fd;

        for (int i = 0; i < MAX_CLIENTS; i++) {
            sd = client_socket[i];
            if (sd > 0) {
                FD_SET(sd, &readfds); // add client sockets
            }
            if (sd > max_sd) {
                max_sd = sd;
            }
        }

        int activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
        if (activity < 0 && errno != EINTR) {
            perror("Select failed");
            exit(1);
        }

        // If the server_fd is set, then there is a new connection
        if (FD_ISSET(server_fd, &readfds)) {
            if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
                                     &addrlen)) < 0) {
                perror("Accept failed");
                exit(1);
            }

            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_socket[i] == 0) {
                    client_socket[i] = new_socket;
                    printf("New connection, socket fd is %d, ip is: %s, port: "
                           "%d\n",
                           new_socket, inet_ntoa(address.sin_addr),
                           ntohs(address.sin_port));
                    break;
                }
            }
        }

        // Check all client sockets
        for (int i = 0; i < MAX_CLIENTS; i++) {
            sd = client_socket[i];
            if (FD_ISSET(sd, &readfds)) {
                int valread = read(sd, buffer, 1024);

                if (valread == 0) {
                    getpeername(sd, (struct sockaddr *)&address,
                                (socklen_t *)&addrlen);
                    printf("Host disconnected, ip %s, port %d\n",
                           inet_ntoa(address.sin_addr),
                           ntohs(address.sin_port));
                    close(sd);
                    client_socket[i] = 0; // Mark the socket as closed
                } else {
                    buffer[valread] = '\0';
                    printf("%s\n", buffer);

                    proc_info *processes = get_proc_info();

                    send(sd, (char *)processes,
                         sizeof(proc_info) * MAX_PROCESSES, 0);
                    free(processes);
                }
            }
        }
    }
    return 0;
}
