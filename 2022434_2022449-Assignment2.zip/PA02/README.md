<h1 align="center">Socket Programming with Performance Analysis
</h1>
<p align="center">
  Saksham Singh, Sarath Chandra Godithi
  <br>
  2022434, 2022449
  <br>
  CSE 232 - Computer Networks - PA02
</p>

## Table of Contents
- [Table of Contents](#table-of-contents)
- [Installation](#installation)
- [Usage](#usage)
- [Question 1](#question-1)
  - [Deliverables](#deliverables)
  - [Server Implementation](#server-implementation)
  - [Client Implementation](#client-implementation)
  - [Results](#results)
- [Question 2](#question-2)
  - [Deliverables](#deliverables-1)
  - [Select Server Implementation](#select-server-implementation)
  - [Performance Analysis](#performance-analysis)
    - [Single Threaded Server](#single-threaded-server)
    - [Multi-Threaded Server](#multi-threaded-server)
    - [Select Server](#select-server)
    - [Client Performance](#client-performance)
      - [Client performance on single server with 10 and 100 threads respectively](#client-performance-on-single-server-with-10-and-100-threads-respectively)
      - [Client performance on multithreaded server with 10 and 100 threads respectively](#client-performance-on-multithreaded-server-with-10-and-100-threads-respectively)
      - [Client performance on select server with 10 and 100 threads respectively](#client-performance-on-select-server-with-10-and-100-threads-respectively)
  - [Conclusion](#conclusion)

## Installation
```
git clone https://github.com/SakshxmSingh/CN_PA02.git
cd CN_PA02
make
```

## Usage
```
taskset -c 0-7 perf stat ./server PORT
taskset -c 0-7 perf stat ./select PORT
taskset -c 0-7 perf stat ./single PORT
taskset -c 12-15 perf stat ./client ADDR PORT THREADS
```

## Question 1
### Deliverables
- Implement a simple server-client model using TCP sockets. The client and the server should be multi threaded and should be able to handle multiple clients simultaneously. 
- The client sends the server a message upon connection and the server responds with info about the two highest CPU utilization processes.

### Server Implementation
- The server can be setup as follows:
```bash
<taskset -c 0-7>  <perf stat> ./server PORT
```
where `PORT` is the port number on which the server listens for connections. The commmands for `perf stat` and `taskset` are used to monitor the performance of the server.

- The server connect follows the classic pipeline of socket creation, binding, listening and accepting connections using the `socket()`, `bind()`, `listen()` and `accept()` functions respectively.
- The server is multi-threaded and uses the `pthread` library to create threads. The server creates a new thread for each client connection.
- The code uses a thread pool to manage the threads. The thread pool is implemented using a set of threads and a mutex lock and cond variable to manage the threads. This is done to avoid the overhead of creating and destroying threads for each client connection.
- Once a client connects, the file descriptor of the client is passed to the thread which carries out the function `handle_client()`. This function reads the message from the client and sends the response.
- The server gets the CPU utilization of the processes by reading the `/proc/` directory. The server reads the `/proc/[pid]/stat` file for each process to get the CPU utilization, and stores the information in a struct defined in `proc.h`. The function `get_proc_info()` defined in `proc.c` reads the `/proc/` directory and returns the CPU utilization of the two highest CPU utilization processes in the struct.
- The server then accordingly sends this struct to the client.

### Client Implementation
- The client can be initiated as follows:
```bash
<taskset -c 12-15>  <perf stat> ./client ADDR PORT THREADS
```
where `ADDR` is the IP address of the server, `PORT` is the port number on which the server listens for connections and `THREADS` is the number of threads to be created by the client. The commmands for `perf stat` and `taskset` are used to monitor the performance of the client.
- The client connects to the server using the `socket()`, `connect()` functions.
- The client takes command line arguments for the server address, port number and the number of threads to be created. The client creates the specified number of threads and each thread connects to the server individually.
- The client sends a message to the server upon connection and reads the response from the server.

### Results
- The server and client were tested on different machines. The server was run on core 0 and the client was run on cores 5-7.
- Server can be setup as follows:
  ![alt text](screenshots/image-3.png)

 
- Initiating the client:
  ![alt text](screenshots/image-4.png)
  and the output is:
    ![alt text](screenshots/image-1.png)
    
    on the server, and on the client
    ![alt text](screenshots/image-2.png)

 The server recieves a hello message from the client which tells about the thread number. The server then sends the information about the two highest CPU utilization processes to the client. The client then prints the information recieved from the server, and the connection is closed. The server then waits for the next client to connect.


## Question 2
### Deliverables
- Analyze the performance of the server client model implemented in Q1 and compare the cases of single-threaded server, multi-threaded server and a server with `select()` system call - thus comparing the performance of the three models.

### Select Server Implementation
- The server can be setup as follows:
```bash
<taskset -c 0-7>  <perf stat> ./server_select PORT
```
- where `PORT` is the port number on which the server listens for connections. The commmands for `perf stat` and `taskset` are used to monitor the performance of the server.
- The server uses the `select()` system call to handle multiple clients. The server creates a set of file descriptors and adds the server socket to the set. The server then uses the `select()` system call to monitor the file descriptors for read events. The server then accepts connections from clients and adds the client file descriptors to the set. The server then uses the `select()` system call to monitor the file descriptors for read events and reads the message from the clients.
- The server then carries out the same process as the multi-threaded server to get the CPU utilization of the processes and sends the information to the client.
- The client implementation remains the same as in Q1.

### Performance Analysis
- The performance of the three models was analyzed using the `perf stat` command. The server and client were run on the different machines. The server was run on core 0-7 and the client was run on cores 12-15.
- The performance of the three models was analyzed by running the server and client multiple times and calculating the average time taken for the server and client to complete.
#### Single Threaded Server
- for runnning the single threaded server:
![alt text](screenshots/image-9.png)
- for running the client with 100 threads:
  ![alt text](screenshots/image-10.png)
- Since the client connection terminates once all the threads are complete, the `seconds time elapsed` value on the client side is crucial for the performance analysis - this value is the time taken for the client to complete and shall be used for comparison.
- Even though the single threaded server has a lower CPU utilization, the time taken for the server to complete is higher than the multi-threaded server. This is because the single threaded server can only handle one client at a time and the clients have to wait for the server to complete before the next client can connect.


#### Multi-Threaded Server
- for running the multi-threaded server:
![alt text](screenshots/image-5.png)
- for running the client with 100 threads:
  ![alt text](screenshots/image-6.png)
- The multi-threaded server has a higher task clock time than the single threaded server, but the time taken for the server to complete is much lower than the single threaded server. This is because the multi-threaded server can handle multiple clients simultaneously and the clients do not have to wait for the server to complete before connecting.
- We also see a significant increase in context switches, cpu migrations and page faults for the multi-threaded server as compared to the single threaded server. This is because the multi-threaded server creates a new thread for each client connection and the context switches and page faults increase with the number of threads created.
- If we run the server on only a single core, the performance of the multi-threaded server will be similar to the single threaded server as the server will not be able to parallelize the client connections across multiple cores.


#### Select Server
- for running the select server:
![alt text](screenshots/image-8.png)
- for running the client with 100 threads:
![alt text](screenshots/image-11.png)
- The select server has a lower task clock time than the multi-threaded server, and it also executes faster than the multi-threaded server. This is because the select server uses the `select()` system call to handle multiple clients and does not create a new thread for each client connection. The select server has a lower context switches, cpu migrations and page faults than the multi-threaded server as it does not create a new thread for each client connection.
- The performance of the select server is highly dependent on `MAX_CLIENTS` value, the higher the value, the more clients the server can handle simultaneously. 
- Select server has the highest cycle count than the other two servers and thus is fastest.

#### Client Performance
- The client performance was analyzed by running the client with 10 threads and  and 100 threads across the different servers.
- The execution of client processes is very dependent on the server performance. The client processes are faster for the multi-threaded server and select server as compared to the single threaded server. This is because the clients do not have to wait for the server to complete before connecting.
- The client also is slower as the number of threads increases, this is because the client has to create and manage multiple threads and the overhead of creating and managing threads increases with the number of threads created - alongside starvation on the server side.
##### Client performance on single server with 10 and 100 threads respectively
  ![alt text](screenshots/image-13.png)
  ![alt text](screenshots/image-12.png)
##### Client performance on multithreaded server with 10 and 100 threads respectively
  ![alt text](screenshots/image-14.png)
  ![alt text](screenshots/image-6.png)
##### Client performance on select server with 10 and 100 threads respectively
  ![alt text](screenshots/image-15.png)
  ![alt text](screenshots/image-11.png)

- As inferred from the above results, an increase in threads on the client side leads to an increase in the time taken for the client to complete. This is because the client has to create and manage multiple threads and the overhead of creating and managing threads increases with the number of threads created. The client performance is also dependent on the server performance, and the client processes are faster for the multi-threaded server and select server as compared to the single threaded server. With the increase in threads, the page faults also increase (alongside context switches and cpu migrations but they could not be inferred on the client device) as the number of threads created increases.
  
### Conclusion
- Strictly performance wise, the select server is the fastest if the `FDSET` is large enough to handle the number of clients. Otherwise, the multi-threaded server is the fastest.
- The single threaded server is the slowest as it can only handle one client at a time and the clients have to wait for the server to complete before connecting -- but it doesnt have the overhead of context switches and cpu migrations, and neither does it have the overhead of managing threads and race conditions.
- The multi-threaded server performance is also very dependent on the amount of cores available to run the server. The more cores available, the more threads can be created and the faster the server can complete.
- The client performance is dependent on the server performance and the client processes are faster for the multi-threaded server and select server as compared to the single threaded server. The client performance is also dependent on the number of threads created, and an increase in threads leads to an increase in the time taken for the client to complete.
