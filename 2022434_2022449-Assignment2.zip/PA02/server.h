#if !defined(_SERVER_H)
#define _SERVER_H

#define BUFSIZE 65536
#define BACKLOG 512
#define MAX_PROCESSES 2

int main(int argc, char *argv[]);
int server_setup(const char* server_port);
int *accept_connection(int server_fd);
void *handle_client(void *arg);

#endif // _SERVER_H
