#include "proc.h"
#include "queue-ll.h"
#include "server.h"
#include "threads.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

// Main function
int main(int argc, char *argv[]) {
    // Check for correct number of arguments
    if (argc != 2) {
        printf("Usage: %s <server_port>\n", argv[0]);
        exit(1);
    }

    const char *server_port = argv[1];

    // Set up server and thread pool
    int server_fd = server_setup(server_port);

    while (1) {
        // Accept connection
        handle_client(accept_connection(server_fd));
    }
    return 0;
}

// Function to set up the server
int server_setup(const char *server_port) {
    // Initialize variables
    int server_fd, status;
    struct addrinfo hints, *res, *p;

    // Set up address info
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    // Get address info
    if ((status = getaddrinfo(NULL, server_port, &hints, &res)) != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(status));
        return 1;
    }

    // Loop through address info and get a socket file descriptor
    for (p = res; p != NULL; p = p->ai_next) {
        if ((server_fd =
                 socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            perror("socket");
            continue;
        }

        // Set socket options to allow binding to the port in case of crash
        if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &(int){1},
                       sizeof(int)) == -1) {
            perror("setsockopt");
            return 1;
        }

        // Bind to the port
        if (bind(server_fd, p->ai_addr, p->ai_addrlen) == -1) {
            close(server_fd);
            perror("bind");
            continue;
        }

        break;
    }

    // Free address info linked list
    freeaddrinfo(res);

    // Check if bind was successful
    if (p == NULL) {
        fprintf(stderr, "Failed to bind\n");
        return 1;
    }

    // Listen for connections
    if (listen(server_fd, BACKLOG) == -1) {
        perror("listen");
        return 1;
    }

    printf("TCP server listening on Port: %d\n",
           ntohs(((struct sockaddr_in *)p->ai_addr)->sin_port));

    return server_fd;
}

// Function to accept connections
int *accept_connection(int server_fd) {
    // Initialize variables
    int *client_fd = malloc(sizeof(int));
    struct sockaddr_storage client_addr;
    socklen_t addr_size = sizeof(client_addr);

    // Accept connection
    *client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_size);

    // Check if accept was successful
    if (*client_fd == -1) {
        perror("accept");
        return NULL;
    }

    // Return client file descriptor
    return client_fd;
}

// Function to handle client
void *handle_client(void *arg) {
    // Initialize variables and free malloc
    int client_fd = *(int *)arg;
    free(arg);
    char buf[BUFSIZE];
    int bytes_read;

    // Get process information
    proc_info *processes = get_proc_info();

    // Loop through and send process information
    while ((bytes_read = recv(client_fd, buf, BUFSIZE, 0)) > 0) {
        buf[bytes_read] = '\0';
        printf("%s\n", buf);
        fflush(stdout);
        send(client_fd, (char *)processes, sizeof(proc_info) * MAX_PROCESSES,
             0);
        printf("Process info sent to client\n");
    }

    // Free process information and close client file descriptor
    free(processes);
    close(client_fd);
    return NULL;
}
