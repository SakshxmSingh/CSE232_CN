#if !defined(_CLIENT_H)
#define _CLIENT_H

#include <netinet/in.h>

typedef struct thread_data {
    int thread_id;
    struct sockaddr_in server_addr;
} thread_data;

void *init_connection(void *arg);
int main(int argc, char const *argv[]);

#endif // _CLIENT_H
